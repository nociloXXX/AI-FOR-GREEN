"""Working online CPU baseline. Edit training, prediction, action and forecast here.

Only the public dataclasses are imported from acn_causal.student_api.
No private scenario, future arrivals, or judge state is accessed.
"""

# =============================================================================
# 文件结构
#   1. MedianModel   中位数基线:站点中位数标签 + 分小时到达直方图 + 物理推演
#   2. LearnedModel  在 MedianModel 之上,用 ExtraTrees 学习需求/停留,
#                    并用 星期x小时 到达率表替换简单直方图
#   3. build_model   门户入口:训练一次,所有请求共用同一个模型
#
# 想改进效果时通常只改 predict / arrival_rate / act / forecast 四个方法;
# 类名、方法名、参数与返回结构必须保持不变(接口约定见 INTERFACE.md)。
# =============================================================================

import numpy as np

from acn_causal.student_api import Prediction


# =============================================================================
# 1. MedianModel —— 中位数基线
#    只使用公开训练数据;不访问隐藏场景、未来到达或评测内部状态。
# =============================================================================
class MedianModel:

    # -----------------------------------------------------------------
    # 1.1 训练:为每个站点汇总 需求/停留中位数 与 分小时到达率
    # -----------------------------------------------------------------
    def __init__(self, training):
        self.labels = {}  # site -> (demand_kwh 中位数, dwell_hours 中位数)
        self.rates = {}   # site -> 长度24的分小时到达率(单位:辆/步)
        for site, frame in training.items():
            self.labels[site] = (
                float(frame.demand_kwh.median()),
                float(frame.dwell_hours.median()),
            )
            # 有到场记录的天数(当前未参与计算,保留作参考)
            days = max(int(frame.day.nunique()), 1)
            # Count observed days, including no-arrival days in the training span.
            span = max((frame.day.max() - frame.day.min()).days + 1, 1)
            # 直方图计数 / 训练跨度天数 / 4(每小时4个15分钟步) = 每步期望到达
            self.rates[site] = np.histogram(frame.hour, bins=np.arange(25))[0] / span / 4

    # -----------------------------------------------------------------
    # 1.2 需求/停留预测:直接返回本站的中位数标签
    # -----------------------------------------------------------------
    def predict(self, f):
        return Prediction(*self.labels[f.site])

    # -----------------------------------------------------------------
    # 1.3 到达率:查分小时直方图(对24取模防越界)
    # -----------------------------------------------------------------
    def arrival_rate(self, site, hour, weekday):
        return float(self.rates[site][int(hour) % 24])

    # -----------------------------------------------------------------
    # 1.4 方法说明:随提交展示的方法/假设/局限
    # -----------------------------------------------------------------
    def explain(self):
        return dict(
            method='site median labels, hour arrival histogram, physics rollout',
            assumptions=['future arrivals are modeled, not known', 'demand and dwell unchanged by intervention'],
            limitations=['median misses vehicle-level variability', 'not causal evidence of user price response'],
        )

    # -----------------------------------------------------------------
    # 1.5 充电决策 act:按"最早离开优先"(EDF)在可用容量内分配功率
    # -----------------------------------------------------------------
    def act(self, o):
        request = []
        for v in o.vehicles:
            if v.charging_complete:
                continue
            pred = self.predict(v.features)
            remaining = max(pred.demand_kwh - v.delivered_kwh, 0.)
            # When predicted demand was low but still connected/unfinished, charge to discover.
            if remaining < .05:
                remaining = v.features.charger_limit_kw * o.dt_hours
            # 预计剩余可充步数,至少1步(避免除零;数值越小越紧急)
            available = max(pred.dwell_hours / o.dt_hours - v.elapsed_steps, 1.)
            request.append((available, v.features.token, min(v.features.charger_limit_kw, remaining / o.dt_hours)))
        # 可用容量 = 站点容量 - 背景负荷;按剩余步数从小到大(EDF)依次分配
        power = {}
        cap = max(o.capacity_kw - o.background_kw, 0.)
        for deadline, token, p in sorted(request):
            g = min(p, cap)
            power[token] = g
            cap -= g
        return power

    # -----------------------------------------------------------------
    # 1.6 负荷预测 forecast:用预测的需求/离开 + 期望到达做物理推演
    # -----------------------------------------------------------------
    def forecast(self, o, horizon_steps, intervention):
        # Honest forecast using predicted demand/departure and sampled expected arrivals.
        # 车辆状态用列表表示:[剩余需求kWh, 剩余停留步数, 充电桩功率上限kW]
        cars = []
        for v in o.vehicles:
            if v.charging_complete:
                continue
            pred = self.predict(v.features)
            cars.append([
                max(pred.demand_kwh - v.delivered_kwh, 0.),
                max(1, int(np.ceil(pred.dwell_hours / o.dt_hours - v.elapsed_steps))),
                v.features.charger_limit_kw,
            ])
        loads = []   # 每一步的EV总负荷kW
        active = []  # 每一步仍在场且未完成的车数
        acc = 0.     # 到达率累加器:每累计满1辆就"期望"到达一辆新车
        for h in range(horizon_steps):
            hour = (o.local_hour + h * o.dt_hours) % 24
            weekday = (o.weekday + int((o.local_hour + h * o.dt_hours) // 24)) % 7
            # ---- 期望到达:按到达率累加,满1辆补一辆取预测参数的6.6kW新车 ----
            acc += self.arrival_rate(o.site, hour, weekday)
            while acc >= 1:
                from acn_causal.student_api import ArrivalFeatures
                pred = self.predict(ArrivalFeatures('forecast', o.site, hour, weekday, 6.6))
                cars.append([pred.demand_kwh, max(1, int(np.ceil(pred.dwell_hours / o.dt_hours))), 6.6])
                acc -= 1
            # ---- 仍在场且未完成的车辆 ----
            valid = [x for x in cars if x[0] > 1e-8 and x[1] > 0]
            active.append(len(valid))
            # ---- 本步容量:capacity_edf 用公开干预容量减背景,否则不限 ----
            cap = max((o.intervention_capacity or o.forecast_capacity)[min(h, len(o.forecast_capacity) - 1)] - o.forecast_background[min(h, len(o.forecast_background) - 1)], 0.) if intervention == 'capacity_edf' else float('inf')
            # ---- EDF分配:剩余停留步数越小越优先 ----
            load = 0.
            for x in sorted(valid, key=lambda x: x[1]):
                p = min(x[2], x[0] / o.dt_hours, cap)
                x[0] -= p * o.dt_hours
                cap -= p
                load += p
            # ---- 时间推进:所有车辆剩余停留步数减1 ----
            for x in cars:
                x[1] -= 1
            loads.append(load)
        return dict(ev_load_kw=loads, active_count=active)


# =============================================================================
# 2. LearnedModel —— ExtraTrees 学习版
#    继承 MedianModel 的 act/forecast,只替换 predict 与 arrival_rate。
# =============================================================================
class LearnedModel(MedianModel):

    # -----------------------------------------------------------------
    # 2.1 训练:需求/停留回归器 + 星期x小时到达率表 + 预测缓存
    # -----------------------------------------------------------------
    def __init__(self, training):
        super().__init__(training)
        from sklearn.ensemble import ExtraTreesRegressor
        self.models = {}      # site -> 已训练的回归器(同时输出 需求kWh / 停留小时)
        self.hour_rates = {}  # site -> 7x24 到达率表(单位:辆/步)
        for site, frame in training.items():
            # ---- 需求/停留回归:特征为 (小时周期编码, 星期, 充电桩功率上限) ----
            X = self._x(frame.hour.to_numpy(), frame.weekday.to_numpy(), frame.charger_limit_kw.to_numpy())
            y = np.column_stack([frame.demand_kwh, frame.dwell_hours])
            model = ExtraTreesRegressor(n_estimators=96, min_samples_leaf=15, max_depth=12, n_jobs=1, random_state=20261008)
            model.fit(X, y)
            self.models[site] = model
            # ---- 到达率:按 星期x小时 计数,除以该星期几在训练跨度内的天数 ----
            counts = np.zeros((7, 24))
            days = np.zeros(7)
            import pandas as pd
            for d in pd.date_range(frame.day.min(), frame.day.max(), freq='D'):
                days[d.dayofweek] += 1
            for w, h in zip(frame.weekday, frame.hour):
                counts[int(w), int(h) % 24] += 1
            self.hour_rates[site] = counts / np.maximum(days[:, None], 1) / 4
            # 预测缓存:同一 (站点, 时刻, 星期, 功率上限) 只推理一次
            self._prediction_cache = {}

    # -----------------------------------------------------------------
    # 2.2 特征构造:小时的正余弦周期编码 + 星期 + 充电桩功率上限
    # -----------------------------------------------------------------
    @staticmethod
    def _x(hour, weekday, pmax):
        return np.column_stack([
            np.sin(np.asarray(hour) * np.pi / 12),
            np.cos(np.asarray(hour) * np.pi / 12),
            np.asarray(weekday),
            np.asarray(pmax),
        ])

    # -----------------------------------------------------------------
    # 2.3 需求/停留预测:先查缓存,未命中则推理并裁剪到合理范围
    # -----------------------------------------------------------------
    def predict(self, f):
        k = (f.site, round(float(f.hour), 3), int(f.weekday), round(float(f.charger_limit_kw), 2))
        if k not in self._prediction_cache:
            y = self.models[f.site].predict(self._x([f.hour], [f.weekday], [f.charger_limit_kw]))[0]
            self._prediction_cache[k] = Prediction(
                float(np.clip(y[0], .01, 150)),  # 需求kWh
                float(np.clip(y[1], .25, 24)),   # 停留小时
            )
        return self._prediction_cache[k]

    # -----------------------------------------------------------------
    # 2.4 到达率:查 星期x小时 表
    # -----------------------------------------------------------------
    def arrival_rate(self, site, hour, weekday):
        return float(self.hour_rates[site][int(weekday) % 7, int(hour) % 24])

    # -----------------------------------------------------------------
    # 2.5 方法说明
    # -----------------------------------------------------------------
    def explain(self):
        return dict(
            method='temporal-trained ExtraTrees96, learned demand/dwell + weekday-hour arrivals + physics composition',
            assumptions=['charger limit known at arrival', 'demand and dwell unchanged by intervention'],
            limitations=['arrival time features cannot identify all driver intent', 'no battery taper; not real behavioral causal inference'],
        )


# =============================================================================
# 3. 门户入口
# =============================================================================
def build_model(training):
    """Portal entry point: train once, return the model used by all requests."""
    return LearnedModel(training)
